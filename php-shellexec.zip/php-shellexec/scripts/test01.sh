#!/bin/bash
# Dummy script that Does `ls -l` command to be run via php-shell exec
ls -l
